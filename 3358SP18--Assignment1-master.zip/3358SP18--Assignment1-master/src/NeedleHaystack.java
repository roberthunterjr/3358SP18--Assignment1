public class NeedleHaystack {
    public NeedleHaystack() {

    }

    public static void main (String[] args) {
        System.out.println("Hello ");
        String needle = MyUtil.getInput("Please enter your needle",1);
    }


}
